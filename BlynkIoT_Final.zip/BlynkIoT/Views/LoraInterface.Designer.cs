﻿namespace BlynkIoT.Views
{
    partial class LoraInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            tbPageControls = new TabPage();
            guna2ShadowPanel8 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            btnCH4 = new Guna.UI2.WinForms.Guna2Button();
            btnCH3 = new Guna.UI2.WinForms.Guna2Button();
            btnCH2 = new Guna.UI2.WinForms.Guna2Button();
            btnCH1 = new Guna.UI2.WinForms.Guna2Button();
            picLed2 = new Guna.UI2.WinForms.Guna2PictureBox();
            picLed1 = new Guna.UI2.WinForms.Guna2PictureBox();
            picLed4 = new Guna.UI2.WinForms.Guna2PictureBox();
            picLed3 = new Guna.UI2.WinForms.Guna2PictureBox();
            tbPageConect = new TabPage();
            indicator = new Guna.UI2.WinForms.Guna2WinProgressIndicator();
            guna2ShadowPanel7 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            picBack = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2ShadowPanel6 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2ShadowPanel5 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            lbPort = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cbPort = new Guna.UI2.WinForms.Guna2ComboBox();
            lbBaude = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cbBaude = new Guna.UI2.WinForms.Guna2ComboBox();
            btnConnect = new Guna.UI2.WinForms.Guna2Button();
            lbstatus = new Guna.UI2.WinForms.Guna2HtmlLabel();
            btnBack1 = new Guna.UI2.WinForms.Guna2Button();
            tbPageLora = new Guna.UI2.WinForms.Guna2TabControl();
            timer1 = new System.Windows.Forms.Timer(components);
            tbPageControls.SuspendLayout();
            guna2ShadowPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLed2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picLed1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picLed4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picLed3).BeginInit();
            tbPageConect.SuspendLayout();
            guna2ShadowPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picBack).BeginInit();
            guna2ShadowPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            guna2ShadowPanel5.SuspendLayout();
            tbPageLora.SuspendLayout();
            SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.BorderRadius = 40;
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // tbPageControls
            // 
            tbPageControls.BackColor = Color.Transparent;
            tbPageControls.BackgroundImage = Properties.Resources.BACKGROUND;
            tbPageControls.Controls.Add(guna2ShadowPanel8);
            tbPageControls.Location = new Point(4, 64);
            tbPageControls.Name = "tbPageControls";
            tbPageControls.Padding = new Padding(3);
            tbPageControls.Size = new Size(556, 310);
            tbPageControls.TabIndex = 1;
            tbPageControls.Text = "CONTROLE CENTRAL";
            // 
            // guna2ShadowPanel8
            // 
            guna2ShadowPanel8.BackColor = Color.Transparent;
            guna2ShadowPanel8.Controls.Add(btnCH4);
            guna2ShadowPanel8.Controls.Add(btnCH3);
            guna2ShadowPanel8.Controls.Add(btnCH2);
            guna2ShadowPanel8.Controls.Add(btnCH1);
            guna2ShadowPanel8.Controls.Add(picLed2);
            guna2ShadowPanel8.Controls.Add(picLed1);
            guna2ShadowPanel8.Controls.Add(picLed4);
            guna2ShadowPanel8.Controls.Add(picLed3);
            guna2ShadowPanel8.FillColor = SystemColors.MenuHighlight;
            guna2ShadowPanel8.Location = new Point(3, 6);
            guna2ShadowPanel8.Name = "guna2ShadowPanel8";
            guna2ShadowPanel8.Radius = 10;
            guna2ShadowPanel8.ShadowColor = Color.Black;
            guna2ShadowPanel8.ShadowShift = 10;
            guna2ShadowPanel8.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            guna2ShadowPanel8.Size = new Size(545, 301);
            guna2ShadowPanel8.TabIndex = 24;
            // 
            // btnCH4
            // 
            btnCH4.BorderRadius = 10;
            btnCH4.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            btnCH4.CheckedState.FillColor = Color.FromArgb(64, 0, 0);
            btnCH4.CustomizableEdges = customizableEdges14;
            btnCH4.DisabledState.BorderColor = Color.DarkGray;
            btnCH4.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCH4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCH4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCH4.FillColor = Color.FromArgb(0, 64, 0);
            btnCH4.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnCH4.ForeColor = Color.White;
            btnCH4.Location = new Point(17, 227);
            btnCH4.Name = "btnCH4";
            btnCH4.ShadowDecoration.CustomizableEdges = customizableEdges15;
            btnCH4.Size = new Size(187, 45);
            btnCH4.TabIndex = 32;
            btnCH4.Text = "ON 4";
            btnCH4.Click += btnCH4_Click;
            // 
            // btnCH3
            // 
            btnCH3.BorderRadius = 10;
            btnCH3.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            btnCH3.CheckedState.FillColor = Color.FromArgb(64, 0, 0);
            btnCH3.CustomizableEdges = customizableEdges16;
            btnCH3.DisabledState.BorderColor = Color.DarkGray;
            btnCH3.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCH3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCH3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCH3.FillColor = Color.FromArgb(0, 64, 0);
            btnCH3.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnCH3.ForeColor = Color.White;
            btnCH3.Location = new Point(17, 155);
            btnCH3.Name = "btnCH3";
            btnCH3.ShadowDecoration.CustomizableEdges = customizableEdges17;
            btnCH3.Size = new Size(187, 45);
            btnCH3.TabIndex = 31;
            btnCH3.Text = "ON 3";
            btnCH3.Click += btnCH3_Click;
            // 
            // btnCH2
            // 
            btnCH2.BorderRadius = 10;
            btnCH2.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            btnCH2.CheckedState.FillColor = Color.FromArgb(64, 0, 0);
            btnCH2.CustomizableEdges = customizableEdges18;
            btnCH2.DisabledState.BorderColor = Color.DarkGray;
            btnCH2.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCH2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCH2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCH2.FillColor = Color.FromArgb(0, 64, 0);
            btnCH2.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnCH2.ForeColor = Color.White;
            btnCH2.Location = new Point(17, 84);
            btnCH2.Name = "btnCH2";
            btnCH2.ShadowDecoration.CustomizableEdges = customizableEdges19;
            btnCH2.Size = new Size(187, 45);
            btnCH2.TabIndex = 30;
            btnCH2.Text = "ON 2";
            btnCH2.Click += btnCH2_Click;
            // 
            // btnCH1
            // 
            btnCH1.BorderRadius = 10;
            btnCH1.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            btnCH1.CheckedState.FillColor = Color.FromArgb(64, 0, 0);
            btnCH1.CustomizableEdges = customizableEdges20;
            btnCH1.DisabledState.BorderColor = Color.DarkGray;
            btnCH1.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCH1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCH1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCH1.FillColor = Color.FromArgb(0, 64, 0);
            btnCH1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnCH1.ForeColor = Color.White;
            btnCH1.Location = new Point(17, 21);
            btnCH1.Name = "btnCH1";
            btnCH1.ShadowDecoration.CustomizableEdges = customizableEdges21;
            btnCH1.Size = new Size(187, 45);
            btnCH1.TabIndex = 18;
            btnCH1.Text = "ON 1";
            btnCH1.Click += btnCH1_Click;
            // 
            // picLed2
            // 
            picLed2.CustomizableEdges = customizableEdges22;
            picLed2.Image = Properties.Resources.LED_OFF;
            picLed2.ImageRotate = 0F;
            picLed2.Location = new Point(360, 74);
            picLed2.Name = "picLed2";
            picLed2.ShadowDecoration.CustomizableEdges = customizableEdges23;
            picLed2.Size = new Size(87, 55);
            picLed2.SizeMode = PictureBoxSizeMode.Zoom;
            picLed2.TabIndex = 29;
            picLed2.TabStop = false;
            // 
            // picLed1
            // 
            picLed1.CustomizableEdges = customizableEdges24;
            picLed1.Image = Properties.Resources.LED_OFF;
            picLed1.ImageRotate = 0F;
            picLed1.Location = new Point(360, 11);
            picLed1.Name = "picLed1";
            picLed1.ShadowDecoration.CustomizableEdges = customizableEdges25;
            picLed1.Size = new Size(87, 55);
            picLed1.SizeMode = PictureBoxSizeMode.Zoom;
            picLed1.TabIndex = 28;
            picLed1.TabStop = false;
            // 
            // picLed4
            // 
            picLed4.CustomizableEdges = customizableEdges26;
            picLed4.Image = Properties.Resources.LED_OFF;
            picLed4.ImageRotate = 0F;
            picLed4.Location = new Point(360, 217);
            picLed4.Name = "picLed4";
            picLed4.ShadowDecoration.CustomizableEdges = customizableEdges27;
            picLed4.Size = new Size(87, 55);
            picLed4.SizeMode = PictureBoxSizeMode.Zoom;
            picLed4.TabIndex = 27;
            picLed4.TabStop = false;
            // 
            // picLed3
            // 
            picLed3.CustomizableEdges = customizableEdges28;
            picLed3.Image = Properties.Resources.LED_OFF;
            picLed3.ImageRotate = 0F;
            picLed3.Location = new Point(360, 145);
            picLed3.Name = "picLed3";
            picLed3.ShadowDecoration.CustomizableEdges = customizableEdges29;
            picLed3.Size = new Size(87, 55);
            picLed3.SizeMode = PictureBoxSizeMode.Zoom;
            picLed3.TabIndex = 26;
            picLed3.TabStop = false;
            // 
            // tbPageConect
            // 
            tbPageConect.BackColor = Color.Transparent;
            tbPageConect.BackgroundImage = Properties.Resources.BACKGROUND;
            tbPageConect.Controls.Add(indicator);
            tbPageConect.Controls.Add(guna2ShadowPanel7);
            tbPageConect.Controls.Add(guna2ShadowPanel6);
            tbPageConect.Controls.Add(guna2ShadowPanel5);
            tbPageConect.Controls.Add(lbstatus);
            tbPageConect.Controls.Add(btnBack1);
            tbPageConect.Location = new Point(4, 64);
            tbPageConect.Name = "tbPageConect";
            tbPageConect.Padding = new Padding(3);
            tbPageConect.Size = new Size(556, 310);
            tbPageConect.TabIndex = 0;
            tbPageConect.Text = "CONEXAO";
            // 
            // indicator
            // 
            indicator.BackColor = Color.Transparent;
            indicator.Location = new Point(481, 267);
            indicator.Name = "indicator";
            indicator.NumberOfCircles = 5;
            indicator.ProgressColor = SystemColors.MenuHighlight;
            indicator.ShadowDecoration.CustomizableEdges = customizableEdges1;
            indicator.Size = new Size(52, 35);
            indicator.TabIndex = 17;
            // 
            // guna2ShadowPanel7
            // 
            guna2ShadowPanel7.BackColor = Color.Transparent;
            guna2ShadowPanel7.Controls.Add(picBack);
            guna2ShadowPanel7.FillColor = SystemColors.MenuHighlight;
            guna2ShadowPanel7.Location = new Point(11, 229);
            guna2ShadowPanel7.Name = "guna2ShadowPanel7";
            guna2ShadowPanel7.Radius = 10;
            guna2ShadowPanel7.ShadowColor = Color.Black;
            guna2ShadowPanel7.ShadowShift = 10;
            guna2ShadowPanel7.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            guna2ShadowPanel7.Size = new Size(106, 85);
            guna2ShadowPanel7.TabIndex = 23;
            // 
            // picBack
            // 
            picBack.CustomizableEdges = customizableEdges2;
            picBack.Image = Properties.Resources.back;
            picBack.ImageRotate = 0F;
            picBack.Location = new Point(3, 3);
            picBack.Name = "picBack";
            picBack.ShadowDecoration.CustomizableEdges = customizableEdges3;
            picBack.Size = new Size(49, 49);
            picBack.SizeMode = PictureBoxSizeMode.Zoom;
            picBack.TabIndex = 0;
            picBack.TabStop = false;
            picBack.Click += guna2PictureBox2_Click;
            // 
            // guna2ShadowPanel6
            // 
            guna2ShadowPanel6.BackColor = Color.Transparent;
            guna2ShadowPanel6.Controls.Add(guna2PictureBox1);
            guna2ShadowPanel6.FillColor = Color.White;
            guna2ShadowPanel6.Location = new Point(275, 6);
            guna2ShadowPanel6.Name = "guna2ShadowPanel6";
            guna2ShadowPanel6.Radius = 10;
            guna2ShadowPanel6.ShadowColor = Color.Black;
            guna2ShadowPanel6.ShadowShift = 10;
            guna2ShadowPanel6.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            guna2ShadowPanel6.Size = new Size(273, 225);
            guna2ShadowPanel6.TabIndex = 22;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.BackColor = Color.White;
            guna2PictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            guna2PictureBox1.BorderRadius = 15;
            guna2PictureBox1.CustomizableEdges = customizableEdges4;
            guna2PictureBox1.Image = Properties.Resources.lora_thethings_842x430;
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(17, 32);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2PictureBox1.Size = new Size(241, 131);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox1.TabIndex = 14;
            guna2PictureBox1.TabStop = false;
            // 
            // guna2ShadowPanel5
            // 
            guna2ShadowPanel5.BackColor = Color.Transparent;
            guna2ShadowPanel5.Controls.Add(lbPort);
            guna2ShadowPanel5.Controls.Add(cbPort);
            guna2ShadowPanel5.Controls.Add(lbBaude);
            guna2ShadowPanel5.Controls.Add(cbBaude);
            guna2ShadowPanel5.Controls.Add(btnConnect);
            guna2ShadowPanel5.FillColor = SystemColors.MenuHighlight;
            guna2ShadowPanel5.Location = new Point(8, 6);
            guna2ShadowPanel5.Name = "guna2ShadowPanel5";
            guna2ShadowPanel5.Radius = 10;
            guna2ShadowPanel5.ShadowColor = SystemColors.InfoText;
            guna2ShadowPanel5.ShadowDepth = 150;
            guna2ShadowPanel5.ShadowShift = 10;
            guna2ShadowPanel5.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.Dropped;
            guna2ShadowPanel5.Size = new Size(261, 225);
            guna2ShadowPanel5.TabIndex = 21;
            // 
            // lbPort
            // 
            lbPort.BackColor = Color.Transparent;
            lbPort.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lbPort.ForeColor = Color.FromArgb(0, 0, 64);
            lbPort.Location = new Point(3, 23);
            lbPort.Name = "lbPort";
            lbPort.Size = new Size(39, 27);
            lbPort.TabIndex = 8;
            lbPort.Text = "Port";
            // 
            // cbPort
            // 
            cbPort.BackColor = Color.Transparent;
            cbPort.BorderRadius = 15;
            cbPort.CustomizableEdges = customizableEdges6;
            cbPort.DrawMode = DrawMode.OwnerDrawFixed;
            cbPort.DropDownStyle = ComboBoxStyle.DropDownList;
            cbPort.FillColor = SystemColors.InactiveCaption;
            cbPort.FocusedColor = Color.FromArgb(94, 148, 255);
            cbPort.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbPort.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbPort.ForeColor = Color.FromArgb(68, 88, 112);
            cbPort.ItemHeight = 30;
            cbPort.Location = new Point(75, 23);
            cbPort.Name = "cbPort";
            cbPort.ShadowDecoration.CustomizableEdges = customizableEdges7;
            cbPort.Size = new Size(133, 36);
            cbPort.TabIndex = 6;
            // 
            // lbBaude
            // 
            lbBaude.BackColor = Color.Transparent;
            lbBaude.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lbBaude.ForeColor = Color.FromArgb(0, 0, 64);
            lbBaude.Location = new Point(3, 87);
            lbBaude.Name = "lbBaude";
            lbBaude.Size = new Size(58, 27);
            lbBaude.TabIndex = 9;
            lbBaude.Text = "Baude";
            // 
            // cbBaude
            // 
            cbBaude.AutoCompleteCustomSource.AddRange(new string[] { "9600", "110", "3311" });
            cbBaude.BackColor = Color.Transparent;
            cbBaude.BorderRadius = 15;
            cbBaude.CustomizableEdges = customizableEdges8;
            cbBaude.DrawMode = DrawMode.OwnerDrawFixed;
            cbBaude.DropDownStyle = ComboBoxStyle.DropDownList;
            cbBaude.FillColor = SystemColors.InactiveCaption;
            cbBaude.FocusedColor = Color.FromArgb(94, 148, 255);
            cbBaude.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbBaude.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbBaude.ForeColor = Color.FromArgb(68, 88, 112);
            cbBaude.ItemHeight = 30;
            cbBaude.Items.AddRange(new object[] { "9600", "110" });
            cbBaude.Location = new Point(75, 78);
            cbBaude.Name = "cbBaude";
            cbBaude.ShadowDecoration.CustomizableEdges = customizableEdges9;
            cbBaude.Size = new Size(133, 36);
            cbBaude.TabIndex = 7;
            // 
            // btnConnect
            // 
            btnConnect.BorderRadius = 15;
            btnConnect.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.ToogleButton;
            btnConnect.CheckedState.FillColor = Color.DarkTurquoise;
            btnConnect.CustomizableEdges = customizableEdges10;
            btnConnect.DisabledState.BorderColor = Color.DarkGray;
            btnConnect.DisabledState.CustomBorderColor = Color.DarkGray;
            btnConnect.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnConnect.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnConnect.FillColor = Color.DarkTurquoise;
            btnConnect.Font = new Font("Segoe UI Semibold", 16.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnConnect.ForeColor = Color.FromArgb(0, 0, 64);
            btnConnect.Location = new Point(54, 130);
            btnConnect.Name = "btnConnect";
            btnConnect.ShadowDecoration.CustomizableEdges = customizableEdges11;
            btnConnect.Size = new Size(177, 51);
            btnConnect.TabIndex = 10;
            btnConnect.Text = "Conectar";
            btnConnect.Click += btnConnect_Click;
            // 
            // lbstatus
            // 
            lbstatus.BackColor = Color.Transparent;
            lbstatus.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lbstatus.ForeColor = Color.FromArgb(128, 64, 64);
            lbstatus.Location = new Point(197, 340);
            lbstatus.Name = "lbstatus";
            lbstatus.Size = new Size(73, 27);
            lbstatus.TabIndex = 4;
            lbstatus.Text = "lbStatus";
            // 
            // btnBack1
            // 
            btnBack1.AutoRoundedCorners = true;
            btnBack1.BorderRadius = 8;
            btnBack1.CustomizableEdges = customizableEdges12;
            btnBack1.DisabledState.BorderColor = Color.DarkGray;
            btnBack1.DisabledState.CustomBorderColor = Color.DarkGray;
            btnBack1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnBack1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnBack1.FillColor = Color.Snow;
            btnBack1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnBack1.ForeColor = Color.FromArgb(0, 0, 64);
            btnBack1.Location = new Point(6, 344);
            btnBack1.Name = "btnBack1";
            btnBack1.ShadowDecoration.CustomizableEdges = customizableEdges13;
            btnBack1.Size = new Size(94, 18);
            btnBack1.TabIndex = 5;
            btnBack1.Text = "VOLTAR";
            btnBack1.Click += guna2Button1_Click;
            // 
            // tbPageLora
            // 
            tbPageLora.Controls.Add(tbPageConect);
            tbPageLora.Controls.Add(tbPageControls);
            tbPageLora.Dock = DockStyle.Fill;
            tbPageLora.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            tbPageLora.ItemSize = new Size(270, 60);
            tbPageLora.Location = new Point(0, 0);
            tbPageLora.Name = "tbPageLora";
            tbPageLora.RightToLeft = RightToLeft.No;
            tbPageLora.SelectedIndex = 0;
            tbPageLora.Size = new Size(564, 378);
            tbPageLora.TabButtonHoverState.BorderColor = Color.Empty;
            tbPageLora.TabButtonHoverState.FillColor = SystemColors.MenuHighlight;
            tbPageLora.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 17F, FontStyle.Regular, GraphicsUnit.Point);
            tbPageLora.TabButtonHoverState.ForeColor = Color.FromArgb(0, 0, 64);
            tbPageLora.TabButtonHoverState.InnerColor = SystemColors.MenuHighlight;
            tbPageLora.TabButtonIdleState.BorderColor = Color.Empty;
            tbPageLora.TabButtonIdleState.FillColor = SystemColors.MenuHighlight;
            tbPageLora.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            tbPageLora.TabButtonIdleState.ForeColor = Color.FromArgb(0, 0, 64);
            tbPageLora.TabButtonIdleState.InnerColor = SystemColors.MenuHighlight;
            tbPageLora.TabButtonSelectedState.BorderColor = Color.Empty;
            tbPageLora.TabButtonSelectedState.FillColor = SystemColors.MenuHighlight;
            tbPageLora.TabButtonSelectedState.Font = new Font("Segoe UI Semibold", 16.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            tbPageLora.TabButtonSelectedState.ForeColor = Color.FromArgb(0, 0, 64);
            tbPageLora.TabButtonSelectedState.InnerColor = Color.FromArgb(0, 0, 64);
            tbPageLora.TabButtonSize = new Size(270, 60);
            tbPageLora.TabButtonTextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            tbPageLora.TabIndex = 19;
            tbPageLora.TabMenuBackColor = SystemColors.MenuHighlight;
            tbPageLora.TabMenuOrientation = Guna.UI2.WinForms.TabMenuOrientation.HorizontalTop;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // LoraInterface
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(564, 378);
            Controls.Add(tbPageLora);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LoraInterface";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LoraInterface";
            Load += LoraInterface_Load;
            tbPageControls.ResumeLayout(false);
            guna2ShadowPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)picLed2).EndInit();
            ((System.ComponentModel.ISupportInitialize)picLed1).EndInit();
            ((System.ComponentModel.ISupportInitialize)picLed4).EndInit();
            ((System.ComponentModel.ISupportInitialize)picLed3).EndInit();
            tbPageConect.ResumeLayout(false);
            tbPageConect.PerformLayout();
            guna2ShadowPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)picBack).EndInit();
            guna2ShadowPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            guna2ShadowPanel5.ResumeLayout(false);
            guna2ShadowPanel5.PerformLayout();
            tbPageLora.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2TabControl tbPageLora;
        private TabPage tbPageConect;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel7;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbPort;
        private Guna.UI2.WinForms.Guna2ComboBox cbPort;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbBaude;
        private Guna.UI2.WinForms.Guna2ComboBox cbBaude;
        private Guna.UI2.WinForms.Guna2Button btnConnect;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbstatus;
        private Guna.UI2.WinForms.Guna2Button btnBack1;
        private TabPage tbPageControls;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel8;
        private Guna.UI2.WinForms.Guna2PictureBox picLed4;
        private Guna.UI2.WinForms.Guna2PictureBox picLed3;
        private Guna.UI2.WinForms.Guna2PictureBox picLed2;
        private Guna.UI2.WinForms.Guna2PictureBox picLed1;
        private Guna.UI2.WinForms.Guna2WinProgressIndicator indicator;
        private Guna.UI2.WinForms.Guna2Button btnCH4;
        private Guna.UI2.WinForms.Guna2Button btnCH3;
        private Guna.UI2.WinForms.Guna2Button btnCH2;
        private Guna.UI2.WinForms.Guna2Button btnCH1;
        private Guna.UI2.WinForms.Guna2PictureBox picBack;
        private System.Windows.Forms.Timer timer1;
    }
}