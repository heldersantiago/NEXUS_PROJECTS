﻿using BlynkIoT.Classes;
using NexusUtils.BlynkIntegration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web;

namespace BlynkIoT.Views
{
    public partial class BlynkInterface : Form
    {
        BlynkService blynk = new BlynkService("93NWr4sYeSdsPOFbc4IBeBLZPBszDS7t");
        private int maxsize = 53;
        private int minsize = 47;
        private int currentsize = 49;

        public BlynkInterface()
        {
            InitializeComponent();
            timer1.Interval = 1000;
            timer2.Interval = 100;
        }
        private void BlynkInterface_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer2.Start();
        }
        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Close(); ;
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void picBack_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            animar();
        }
        private void animar()
        {
            if (currentsize < maxsize)
            {
                currentsize += 1;
                picBack.Size = new Size(currentsize, currentsize);
            }
            else if (currentsize > minsize)
            {
                currentsize -= 1;
                picBack.Size = new Size(currentsize, currentsize);

            }
        }

        private async void timer1_Tick(object sender, EventArgs e)
        {
            DeviceStatus deviceStatus = await blynk.GetDeviceStatusAsync();
            if (deviceStatus == DeviceStatus.Connected)
            {
                indicator.Start();
            }
            else if (deviceStatus == DeviceStatus.Disconnected)
            {
                indicator.Stop();
            }
            UpdateStates();
        }

        private async void UpdateStates()
        {
            try
            {
                string pin1 = await blynk.ReadVirtualPinValueAsync("v0");
                if (pin1 == "1")
                {
                    btnCH1.Checked = true;
                    btnCH1.Text = "OFF 1";
                    picLed1.Image = Properties.Resources.LED_ON;

                }
                else if (pin1 == "0")
                {
                    btnCH1.Checked = false;
                    btnCH1.Text = "ON 1";
                    picLed1.Image = Properties.Resources.LED_OFF;

                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Updating Data BTN 2

            try
            {
                string pin1 = await blynk.ReadVirtualPinValueAsync("v1");
                if (pin1 == "1")
                {
                    btnCH2.Checked = true;
                    btnCH2.Text = "OFF 2";
                    picLed2.Image = Properties.Resources.LED_ON;
                }
                else if (pin1 == "0")
                {
                    btnCH2.Checked = false;
                    btnCH2.Text = "ON 2";
                    picLed2.Image = Properties.Resources.LED_OFF;
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message);
            }



            //Updating Data BTN 3

            try
            {
                string pin1 = await blynk.ReadVirtualPinValueAsync("v2");
                if (pin1 == "1")
                {
                    btnCH3.Checked = true;
                    btnCH3.Text = "OFF 3";
                    picLed3.Image = Properties.Resources.LED_ON;
                }
                else if (pin1 == "0")
                {
                    btnCH3.Checked = false;
                    btnCH3.Text = "ON 3";
                    picLed3.Image = Properties.Resources.LED_OFF;
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Updating Data BTN 4

            try
            {
                string pin1 = await blynk.ReadVirtualPinValueAsync("v3");
                if (pin1 == "1")
                {
                    btnCH4.Checked = true;
                    btnCH4.Text = "OFF 4";
                    picLed4.Image = Properties.Resources.LED_ON;
                }
                else if (pin1 == "0")
                {
                    btnCH4.Checked = false;
                    btnCH4.Text = "ON 4";
                    picLed4.Image = Properties.Resources.LED_OFF;
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void btnCH1_Click(object sender, EventArgs e)
        {
            if (btnCH1.Checked)
            {
                try { await blynk.UpdateVirtualPinAsync("V0", 1); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }

                btnCH1.Text = "OFF 1";
                picLed1.Image = Properties.Resources.LED_ON;
            }
            else
            {
                try { await blynk.UpdateVirtualPinAsync("V0", 0); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }

                btnCH1.Text = "ON 1";
                picLed1.Image = Properties.Resources.LED_OFF;
            }
        }

        private async void btnCH2_Click(object sender, EventArgs e)
        {
            if (btnCH2.Checked)
            {
                try { await blynk.UpdateVirtualPinAsync("V1", 1); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }

                btnCH2.Text = "OFF 2";
                picLed2.Image = Properties.Resources.LED_ON;
            }
            else
            {
                try { await blynk.UpdateVirtualPinAsync("V1", 0); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }

                btnCH2.Text = "ON 2";
                picLed2.Image = Properties.Resources.LED_OFF;
            }
        }

        private async void btnCH3_Click(object sender, EventArgs e)
        {
            if (btnCH3.Checked)
            {
                try { await blynk.UpdateVirtualPinAsync("V2", 1); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }
                btnCH3.Text = "OFF 3";
                picLed3.Image = Properties.Resources.LED_ON;
            }
            else
            {
                try { await blynk.UpdateVirtualPinAsync("V2", 0); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }
                btnCH3.Text = "ON 3";
                picLed3.Image = Properties.Resources.LED_OFF;
            }
        }

        private async void btnCH4_Click(object sender, EventArgs e)
        {
            if (btnCH4.Checked)
            {
                try { await blynk.UpdateVirtualPinAsync("V3", 1); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }
                btnCH4.Text = "OFF 4";
                picLed4.Image = Properties.Resources.LED_ON;
            }
            else
            {
                try { await blynk.UpdateVirtualPinAsync("V3", 0); }
                catch (HttpRequestException ex) { MessageBox.Show(ex.Message); }
                btnCH4.Text = "ON 4";
                picLed4.Image = Properties.Resources.LED_OFF;
            }
        }

    }
}
