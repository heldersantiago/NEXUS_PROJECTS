﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
//using Microsoft.Extensions.ObjectPool;

namespace BlynkIoT.Classes
{
    public class ConexaoLora
    {
        private SerialPort serialPort = new SerialPort();
        public string Port { get; set; }
        public int Baude { get;set; }
        public bool isConnected { get; private set; }
        public event Action<string> DataReceived;

        public ConexaoLora(string port, int baude)
        {
            Port = port;
            Baude = baude;
            serialPort.DataReceived += SerialPort_DataReceived1;
        }

        public ConexaoLora() 
        {
            serialPort.DataReceived += SerialPort_DataReceived1;
        }
        private void SerialPort_DataReceived1(object sender, SerialDataReceivedEventArgs e)
        {
            string data = serialPort.ReadExisting();
            DataReceived?.Invoke(data);
        }

        public bool Connect() 
        {
            serialPort.PortName = Port;
            serialPort.BaudRate = Baude;

            try
            {
                serialPort.Open();
                isConnected = true;
                return true;
            }
            catch (Exception)
            {
                isConnected = false;
                return false;
            }
        }

        public void Disconnect() 
        {
          if(isConnected) { serialPort.Close(); isConnected = false;}
        }

        public void SendMessage(string message)
        {   
            if(isConnected) { serialPort.Write(message); }
        }
    }
}
