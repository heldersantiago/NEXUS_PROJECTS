
using BlynkIoT.Views;
using NexusUtils.BlynkIntegration;
using System.Diagnostics;
using System;

namespace BlynkIoT
{
    public partial class Form1 : Form
    {
        BlynkInterface blynkInterface = new BlynkInterface();
        public Form1()
        {
            InitializeComponent();
        }
        private async void Form1_Load(object sender, EventArgs e)
        {
            this.Opacity = 0; // Define a opacidade inicial como 0 (totalmente transparente)
            while (this.Opacity < 1)
            {
                this.Opacity += 0.05; // Incrementa a opacidade gradualmente
                await Task.Delay(50); // Aguarda um pequeno intervalo para criar o efeito suave
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            LoraInterface loraInterface = new LoraInterface();
            this.Hide();
            loraInterface.Show();
        }

        private async void guna2Button2_Click(object sender, EventArgs e)
        {
            BlynkService blynk = new BlynkService("93NWr4sYeSdsPOFbc4IBeBLZPBszDS7t");
            DeviceStatus deviceStatus = await blynk.GetDeviceStatusAsync();
            if (deviceStatus == DeviceStatus.Connected)
            {
                this.Hide();
                blynkInterface.Show();
            }
            else if (deviceStatus == DeviceStatus.Disconnected)
            {
                MessageBox.Show("Servidor Blynk is Offline", "Blynk Server", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {
            //blynkInterface.Close();
            //loraInterface.Close();
            //this.Close();
        }

        private void btnServer_Click(object sender, EventArgs e)
        {
            try
            {
                // Caminho para o arquivo .bat
                string filePath = "C:\\Users\\hps\\Documents\\Arduino\\libraries\\Blynk\\scripts\\blynk-ser.bat";

                // Verifica se o arquivo existe
                if (System.IO.File.Exists(filePath))
                {
                    // Inicia o arquivo .bat
                    Process.Start(filePath);
                }
                else
                {
                    MessageBox.Show("Arquivo nao econtrado");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao abrir o arquivo .bat: " + ex.Message);
            }
        }
    }
}
