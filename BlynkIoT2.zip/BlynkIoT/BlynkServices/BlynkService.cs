﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace NexusUtils.BlynkIntegration
{
    public enum DeviceStatus
    {
        Connected,
        Disconnected,
    }

    public class BlynkService
    {
        private readonly string Token;

        public BlynkService(string Token)
        {
            this.Token = Token;
        }

        /// <summary>
        /// Updates the VirtualPin Value.
        /// </summary>
        /// <param name="value">
        /// The Value.
        /// </param>
        /// <returns></returns>
        public async Task UpdateVirtualPinAsync(string virtualPin, int value)
        {
             using HttpClient httpClient = new();    
             await httpClient.GetAsync($"https://ny3.blynk.cloud/external/api/update?token={Token}&{virtualPin}={value}");
        }


        /// <summary>
        /// Gets the Value of The VirtualPin.
        /// </summary>
        /// <param name="VirtualPin">
        /// The VirtualPin to Read.
        /// </param>
        /// <returns></returns>
        public async Task<string> ReadVirtualPinValueAsync(string VirtualPin)
        {
            using HttpClient httpClient = new();

            var response = await httpClient.GetAsync($"https://ny3.blynk.cloud/external/api/get?token={Token}&{VirtualPin}");

            var data = await response.Content.ReadAsStringAsync();

            return data;
        }

        /// <summary>
        /// Gets the Device Status.
        /// </summary>
        /// <returns>
        /// The Device Status.
        /// </returns>
        public async Task<DeviceStatus> GetDeviceStatusAsync()
        {
             using HttpClient httpClient = new HttpClient();

             var response = await httpClient.GetAsync($"https://ny3.blynk.cloud/external/api/isHardwareConnected?token={Token}");
             response.EnsureSuccessStatusCode();

             var data = await response.Content.ReadAsStringAsync();
            
             if (data == "true")
                 return DeviceStatus.Connected;
             else
                 return DeviceStatus.Disconnected;            
        }
    }
}
