﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;


namespace BlynkIoT.DATABASE
{
    public class DataBase
    {
        private MySqlConnection mySql;
        public int Id { get; set; }
        public string Server_Name { get; set; }
        public string Hostname { get; set; }
        public string Database_Name { get; set; }
        public string Password { get; set; }
        public string data { get; set; }


        public DataBase(string servername,string database, string host ,string pass)
        {
            Server_Name = servername;
            Database_Name = database;
            Hostname = host;
            Password = pass;
        }
        public void ConnectToDb()
        {
            string connectionString = $"Server={Server_Name}; Database={Database_Name}; Uid={Hostname}; Password={Password};";

            try
            {
                mySql = new MySqlConnection(connectionString);
                mySql.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show($"Erro ao conectar ao banco de dados: {ex.Message}");
            }
        }
        public string Show_tables()
        { 
            string command = "SELECT * FROM blynk_lora_info";
            MySqlDataAdapter mySqlData = new MySqlDataAdapter(command, mySql);
            DataSet dataSet = new DataSet();
            
            mySqlData.Fill(dataSet);
            return data;
        }

    }
}
