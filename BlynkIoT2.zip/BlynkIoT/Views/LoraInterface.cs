﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BlynkIoT.Classes;
using System.IO.Ports;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using BlynkIoT.DATABASE;

namespace BlynkIoT.Views
{
    public partial class LoraInterface : Form
    {
        MySqlConnection mySqlConnection = new MySqlConnection("SERVER=LOCALHOST ; DATABASE=blynkiotdb ; UID=root ;PASSWORD=heldersantiago273;");
        //Classes instancies
        BlynkInterface blynk = new BlynkInterface();
        Form1 form1 = new Form1();
        private ConexaoLora conexao;
        DataBase DB = new DataBase("LOCALHOST", "blynkiotdb", "root", "heldersantiago273");
        //Variables
        private int maxsize = 53;
        private int minsize = 47;
        private int currentsize = 49;

        private async void LoraInterface_Load(object sender, EventArgs e)
        {
            this.Opacity = 0; // Define a opacidade inicial como 0 (totalmente transparente)
            while (this.Opacity < 1)
            {
                this.Opacity += 0.05; // Incrementa a opacidade gradualmente
                await Task.Delay(50); // Aguarda um pequeno intervalo para criar o efeito suave
            }
            string[] portas = SerialPort.GetPortNames();
            cbPort.Items.AddRange(portas);
            indicator.Start();
            timer1.Start();
        }

        public LoraInterface()
        {
            InitializeComponent();
            InitializeSerialPort();
        }

        private void InitializeSerialPort()
        {
            //conexao = new ConexaoLora(cbPort.Text, int.Parse(cbBaude.Text));
            conexao = new ConexaoLora();

            this.conexao.DataReceived += Conexao_DataReceived;
        }

        private void Conexao_DataReceived(string data)
        {

            if (InvokeRequired)
            {
                BeginInvoke(new Action(() => Conexao_DataReceived(data)));
            }
            else
            {
                tbMessage.Text = data;
                string[] datas = data.Split(',');

                //Updating the Buttons States
                if (datas.Length >= 4)
                {
                    //LED1

                    if (datas[0].Trim() == "1")
                    {
                        btnCH1.Checked = true;
                        btnCH1.Text = "OFF 1";
                        picLed1.Image = Properties.Resources.LED_ON;


                    }
                    else if (datas[0] == "0")
                    {
                        btnCH1.Checked = false;
                        btnCH1.Text = "ON 1";
                        picLed1.Image = Properties.Resources.LED_OFF;

                    }

                    //LED2

                    if (datas[1].Trim() == "1")
                    {
                        btnCH2.Checked = true;
                        btnCH2.Text = "OFF 2";
                        picLed2.Image = Properties.Resources.LED_ON;

                    }
                    else if (datas[1] == "0")
                    {
                        btnCH2.Checked = false;
                        btnCH2.Text = "ON 2";
                        picLed2.Image = Properties.Resources.LED_OFF;

                    }

                    //LED3

                    if (datas[2].Trim() == "1")
                    {
                        btnCH3.Checked = true;
                        btnCH3.Text = "OFF 3";
                        picLed3.Image = Properties.Resources.LED_ON;

                    }
                    else if (datas[2] == "0")
                    {
                        btnCH3.Checked = false;
                        btnCH3.Text = "ON 3";
                        picLed3.Image = Properties.Resources.LED_OFF;

                    }

                    //LED4

                    if (datas[3].Trim() == "1")
                    {
                        btnCH4.Checked = true;
                        btnCH4.Text = "OFF 4";
                        picLed4.Image = Properties.Resources.LED_ON;

                    }
                    else if (datas[3] == "0")
                    {
                        btnCH4.Checked = false;
                        btnCH4.Text = "ON 4";
                        picLed4.Image = Properties.Resources.LED_OFF;
                    }

                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.DestroyHandle();
            form1.Show();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (btnConnect.Checked)
            {
                try
                {
                    conexao.Port = cbPort.Text;
                    conexao.Baude = int.Parse(cbBaude.Text);
                    if (conexao.Connect())
                    {
                        lbstatus.Text = "ABERTO";
                        btnConnect.Text = "Desconectar";
                        indicator.Stop();
                        indicator.Hide();
                        tbPageLora.SelectedTab = tbPageControls;
                    }

                }
                catch
                {
                    MessageBox.Show("Erro desconhecido!");
                }
            }
            else
            {
                conexao.Disconnect();
                btnConnect.Text = "Conectar";
                indicator.Stop();
            }
        }

        private void btnCloseLora_Click(object sender, EventArgs e)
        {
            form1.Close();
            blynk.Close();
            Close();
        }

        private void btnCH1_Click(object sender, EventArgs e)
        {
            if (btnCH1.Checked)
            {
                picLed1.Image = Properties.Resources.LED_ON;
                conexao.SendMessage("a");
                btnCH1.Text = "OFF 1";
            }
            else
            {
                picLed1.Image = Properties.Resources.LED_OFF;
                conexao.SendMessage("b");
                btnCH1.Text = "ON 1";

            }
        }

        private void btnCH2_Click(object sender, EventArgs e)
        {
            if (btnCH2.Checked)
            {
                picLed2.Image = Properties.Resources.LED_ON;
                conexao.SendMessage("c");
                btnCH2.Text = "OFF 2";
            }
            else
            {
                picLed2.Image = Properties.Resources.LED_OFF;
                conexao.SendMessage("d");
                btnCH2.Text = "ON 2";

            }
        }

        private void btnCH3_Click(object sender, EventArgs e)
        {
            if (btnCH3.Checked)
            {
                picLed3.Image = Properties.Resources.LED_ON;
                conexao.SendMessage("e");
                btnCH3.Text = "OFF 3";

            }
            else
            {
                picLed3.Image = Properties.Resources.LED_OFF;
                conexao.SendMessage("f");
                btnCH3.Text = "ON 3";

            }
        }

        private void btnCH4_Click(object sender, EventArgs e)
        {
            if (btnCH4.Checked)
            {
                picLed4.Image = Properties.Resources.LED_ON;
                conexao.SendMessage("g");
                btnCH4.Text = "OFF 4";
            }
            else
            {
                picLed4.Image = Properties.Resources.LED_OFF;
                conexao.SendMessage("h");
                btnCH4.Text = "ON 4";
            }
        }

        private void guna2PictureBox2_Click(object sender, EventArgs e)
        {
            if (!conexao.isConnected)
            {
                this.Close();
                form1.Show();
            }
            else
            {
                MessageBox.Show("Desconecte-se primeiro!", "Porta is Opened", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            animar();

            DateTime currentDate = DateTime.Now;

            // Exibir a data no TextBox
            lbDate.Text = currentDate.ToString();
        }


        private void animar()
        {
            if (currentsize < maxsize)
            {
                currentsize += 1;
                picBack.Size = new Size(currentsize, currentsize);
            }
            else if (currentsize > minsize)
            {
                currentsize -= 1;
                picBack.Size = new Size(currentsize, currentsize);
            }
        }

        private void guna2Button1_Click_1(object sender, EventArgs e)
        {
            MySqlDataAdapter mySqlData = new MySqlDataAdapter("SELECT * FROM blynk_lora_info", mySqlConnection);

            DataSet dataSet = new DataSet();

            mySqlData.Fill(dataSet);
            DataGridDatabase.DataSource = dataSet.Tables[0];
        }
    }
}
